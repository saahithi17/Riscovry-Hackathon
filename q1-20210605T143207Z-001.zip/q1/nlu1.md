## intent:q1
- I have nothing
- I have [diabetes](diseases)
- I have [cancer](diseases) and [thyroid](diseases)
- I have [no](diseases) disease
- I have [High Blood pressure](diseases)
- [Cancer](diseases) [thyroid](diseases) [Fever](diseases)
- I have [Cancer](diseases) [thyroid](diseases) [Fever](diseases)
- Yes I have [Corona](diseases)
- Yes,I have [Fever](diseases)
- Just [cough](diseases)
- Running with [high Fever](diseases)
- I am suffering from [Headache](diseases) 
- [Nothing](diseases)
- [None](diseases)

## lookup: diseases
- dis.txt

